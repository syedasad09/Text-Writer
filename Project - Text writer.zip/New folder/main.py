import pygame
import sys
import time
import random

background_image = 'new1.png'
restart_logo = 'restart.png'

class Type_Game:
    def __init__(self):
        self.color_heading = (255,165,0)
        self.color_text = (255,165,0)
        self.color_results = (216, 222, 146)
        self.w = 1000
        self.h = 600
        self.screen = pygame.display.set_mode((self.w, self.h))
        self.active = False
        self.results = "Accuracy: 0% ~ Words Per Minute: 0"
        self.accuracy = "0%"
        self.reset = True
        self.max_accuracy = 0
        self.selected_mode = None  # Initialize selected_mode
        pygame.init()
        pygame.display.set_caption("Typing Game")
        self.bg_img = pygame.image.load(background_image)
        self.bg_img = pygame.transform.scale(self.bg_img, (self.w, self.h))

    def write_text(self, screen, title, title_font_size, names, names_font_size, y, text_color, mode_text=None):
        title_font = pygame.font.Font("kalam-bold.ttf", title_font_size)
        names_font = pygame.font.Font("kalam-bold.ttf", names_font_size)

        title_text = title_font.render(title, 1, text_color)
        title_box = title_text.get_rect(center=(self.w / 2, y))
        screen.blit(title_text, title_box)

        if mode_text:
            mode_font = pygame.font.Font("kalam.ttf", 20)
            mode_surface = mode_font.render(mode_text, 1, text_color)
            mode_box = mode_surface.get_rect(center=(self.w / 2, y + 30))
            screen.blit(mode_surface, mode_box)

        for i, name in enumerate(names):
            # Adjust the left and top values to move the names to the bottom left
            name_text = names_font.render(name, 1, text_color)
            name_box = name_text.get_rect(left=20, top=self.h - 20 - (len(names) - i) * 30)
            screen.blit(name_text, name_box)

    def show_result(self, screen):
        count = 0
        for i, c in enumerate(self.word):
            try:
                if self.input_text[i] == c:
                    count += 1
            except:
                pass
        self.accuracy = (count * 100) / len(self.word)
        if self.accuracy > self.max_accuracy:
            self.max_accuracy = self.accuracy

        self.wpm = (len(self.input_text) * 60) / (5 * (time.time() - self.start_time))
        self.results = f"Accuracy: {round(self.accuracy)}% ~ WPM: {round(self.wpm)}"
        self.reply_img = pygame.image.load(restart_logo)
        self.reply_img = pygame.transform.scale(self.reply_img, (200, 120))
        screen.blit(self.reply_img, (self.w / 2 - 100, self.h - 150))

    def get_sentence(self, mode):
        filename = f"{mode.lower()}.txt"
        try:
            with open(filename) as file:
                sentences = file.readlines()
                return random.choice(sentences).strip()
        except FileNotFoundError:
            print(f"Error: File {filename} not found.")
            return ""

    def select_mode(self):
        modes = {"easy": (0, 200), "normal": (250, 550), "hard": (500, 700), "impossible": (750, 900)}

        # Load the background image for mode selection
        background_image = pygame.image.load('new2.png')  # Replace 'your_background_image.jpg' with the actual image file path
        background_image = pygame.transform.scale(background_image, (self.w, self.h))

        self.screen.blit(background_image, (0, 0))

        font = pygame.font.Font("kalam.ttf", 36)

        text = font.render( "Select a mode:", True, (255,165,0))
        self.screen.blit(text, (self.w / 2 - text.get_width() / 2, 150))

        # Reset selected_mode to None before mode selection begins
        self.selected_mode = None

        for mode, (start_x, end_x) in modes.items():
            text = font.render(mode.capitalize(), True, (255,165,0))
            text_rect = text.get_rect(center=(start_x + (end_x - start_x) / 2, 300))
            self.screen.blit(text, text_rect)

        pygame.display.flip()

        while self.selected_mode not in modes:
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONUP:
                    x, y = pygame.mouse.get_pos()
                    for mode, (start_x, end_x) in modes.items():
                        start_y, end_y = 250, 350  # Adjust these values based on your needs
                        if start_x <= x <= end_x and start_y <= y <= end_y:
                            self.selected_mode = mode

        return self.selected_mode

    def restart_game(self):
        time.sleep(1)

        self.reset = False
        self.end = False
        self.input_text = ''
        self.word = self.get_sentence(self.selected_mode)
        self.start_time = 0  # Set start_time to 0 initially
        self.screen.fill((0, 0, 0))
        self.screen.blit(self.bg_img, (0, 0))
        title = "Typing Master!"
        names = ["Created by: "," ","Kamran Ali", " ", "Abbas Tariq"]
        title_font_size = 30
        names_font_size = 24
        self.write_text(self.screen, title, title_font_size, names, names_font_size, 50, self.color_heading)
        self.write_text(self.screen, self.word, title_font_size, [], names_font_size, 300, self.color_text)

    def run(self):
        self.selected_mode = self.select_mode()
        self.restart_game()

        self.running = True
        countdown_start_time = 0  # Initialize countdown_start_time
        countdown_duration = 60

        while self.running:
            clock = pygame.time.Clock()
            transparent_surface = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
            pygame.draw.rect(transparent_surface, (0, 0, 0, 128), (0, 200, self.w, 70), 0)
            self.screen.blit(self.bg_img, (0, 0))  # Draw the background image
            self.screen.blit(transparent_surface, (0, 0))  # Blit the transparent surface onto the screen
            title = "Typing Master "
            names = ["Created by: "," ","Kamran Ali", " ", "Abbas Tariq"]
            title_font_size = 30
            names_font_size = 24
            self.write_text(self.screen, title, title_font_size, names, names_font_size, 50, self.color_heading, f"Mode: {self.selected_mode.capitalize()}")
            pygame.draw.rect(self.screen, (0, 0, 0), (0, 200, self.w, 70), 2)
            self.write_text(self.screen, self.word, title_font_size, [], names_font_size, 300, self.color_text)
            self.write_text(self.screen, self.input_text, title_font_size, [], names_font_size, 240, (255, 255, 255))

            # Display timer above the text box
            if self.active and not self.end:
                remaining_time = max(0, int(countdown_duration - (time.time() - countdown_start_time)))
                timer_text = f"Time Left: {round(remaining_time)}s"
                timer_font = pygame.font.Font("kalam.ttf", 24)
                timer_surface = timer_font.render(timer_text, 1, (255, 255, 255))
                self.screen.blit(timer_surface, (self.w - 200, 150))

                # Check if time is up
                if remaining_time == 0:
                    self.show_result(self.screen)
                    self.end = True

            # Render restart button regardless of the end condition
            if self.end:
                self.write_text(self.screen, self.results, title_font_size, [], names_font_size, 400, self.color_results)
                self.reply_img = pygame.image.load(restart_logo)
                self.reply_img = pygame.transform.scale(self.reply_img, (200, 120))
                self.screen.blit(self.reply_img, (self.w / 2 - 100, self.h - 150))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONUP:
                    x, y = pygame.mouse.get_pos()
                    if 50 <= x <= 750 and 200 <= y <= 250:  # Adjusted input box coordinates
                        self.active = True
                        if not self.start_time:  # Start the timer only if it hasn't started yet
                            countdown_start_time = time.time()
                            self.start_time = time.time()
                        self.input_text = ''
                    if 400 <= x <= 600 and 450 <= y <= 570 and self.end:  # Adjusted restart button coordinates
                        self.selected_mode = self.select_mode()
                        self.restart_game()
                        countdown_start_time = time.time()
                elif event.type == pygame.KEYDOWN:
                    if self.active and not self.end:
                        if event.key == pygame.K_RETURN:
                            if self.input_text == self.word:
                                self.word = self.get_sentence(self.selected_mode)
                                self.start_time = time.time()
                                self.input_text = ''  # Clear the input box
                            else:
                                self.show_result(self.screen)
                                self.end = True
                        elif event.key == pygame.K_BACKSPACE:
                            self.input_text = self.input_text[:-1]
                        else:
                            self.input_text += event.unicode

            pygame.display.update()
            clock.tick(60)

        # Display final results after 1 minute
        if not self.end:
            self.show_result(self.screen)
            pygame.display.update()
            time.sleep(2)  # Wait for 2 seconds before exiting

if __name__ == '__main__':
    Type_Game().run()
